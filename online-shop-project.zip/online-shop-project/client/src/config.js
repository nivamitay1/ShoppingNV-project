module.exports = {
  domain:
    //  "http://localhost:3000/api/v1",
    "https://online-shop-niv.herokuapp.com/api/v1",
};
